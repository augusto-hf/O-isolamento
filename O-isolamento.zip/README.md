# O-isolamento
Livro Jogo
Um projeto de faculdade
